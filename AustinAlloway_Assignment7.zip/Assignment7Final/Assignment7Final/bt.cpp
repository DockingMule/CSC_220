//bt.cpp - file contains member functions
#include "bt.h"
#include <iostream>
using namespace std;
//Constructor
BT::BT()
{
	root = NULL;
}

//---------------------------------------
//Insert new item in BST
//--------------------------------------
void BT::insert(int d)
{
	node* t = new node;
	node* parent;

	t->data = d;
	t->left = NULL;
	t->right = NULL;
	parent = NULL;

	if (isEmpty())
		root = t;
	else
	{
		//Note: ALL insertions are as leaf nodes
		node* curr;
		curr = root;
		// Find the Node's parent
		while (curr)
		{
			parent = curr;
			if (t->data > curr->data)
				curr = curr->right;
			else
				curr = curr->left;
		}
		if (t->data < parent->data)
			parent->left = t;
		else
			parent->right = t;
	}
}

//--------------------------------------------------
//Function - Inorder traversing driver
//--------------------------------------------------
void BT::print_inorder()
{
	inorderTrav(root);
}

//--------------------------------------------------------
//Function - Inorder traversing
//---------------------------------------------------------
void BT::inorderTrav(node* p)
{
	if (isEmpty())
	{
		cout << "	Tree is empty." << endl;
		return;
	}


	if (p != NULL)
	{
		inorderTrav(p->left);

		cout << "	    " << p->data;

		if (p->left != NULL)
			cout << "		       " << p->left->data;
		else
			cout << "		      NIL";

		if (p->right != NULL)
			cout << "		     " << p->right->data << endl;
		else
			cout << "		    NIL" << endl;

		inorderTrav(p->right);
	}
	else
		return;
}

//-------------------------------------------------
//Calls for search
//-------------------------------------------------

void BT::callSearch(int x) {
	BT::searchBST(root, x);
}

//-------------------------------------------------
//Searches BST for a specific node
//-------------------------------------------------
void BT::searchBST(node* root, int x) {
	if (root == NULL) {
		cout << x << " is not found in the BST." << endl;
		return;
	}
	if (root->data == x) {
		cout << x << " is found in the BST." << endl;
		return;
	}

	if (root->data > x) {
		BT::searchBST(root->left, x);
		return;
	}
	// right subtree recurion
	if (root->data < x) {
		BT::searchBST(root->right, x);
		return;
	}
}

//-------------------------------------------------
//Calls for delete
//-------------------------------------------------

void BT::calldelete(int x) {
	BT::deleteNode(root, x);
}

//---------------------------------------------------
//Delete item from BST
//---------------------------------------------------
BT::node* BT::deleteNode(node* currentNode, int value){
		if (currentNode == NULL) // empty tree
			return NULL;
		else if (value < currentNode->data) // value is less than node's number. so go to left subtree
			currentNode->left = deleteNode(currentNode->left, value);
		else if (value > currentNode->data) // value is greater than node's number. so go to right subtree
			currentNode->right = deleteNode(currentNode->right, value);
		else // node found. Let's delete it!
		{
			//node has no child
			if (currentNode->left == NULL && currentNode->right == NULL)
			{
				currentNode = NULL;
			}
			else if (currentNode->left == NULL) // node has only right child
			{
				currentNode = currentNode->right;
			}
			else if (currentNode->right == NULL) // node has only left child
			{
				currentNode = currentNode->left;
			}
			else // node has two children
			{
				node *tempNode = findMinimum(currentNode->right);
				currentNode->data = tempNode->data;
				currentNode->right = deleteNode(currentNode->right, tempNode->data);
			}

		}

		return currentNode;
	}
//------------------------------------------------------
//Find Minumum
//-----------------------------------------------------
BT::node* BT::findMinimum(node* currentNode)
{
	if (currentNode->left == NULL)
		return currentNode;

	return findMinimum(currentNode->left);
}
//-----------------------------------------------------
//Count driver
//----------------------------------------------------
int BT::count() {
	return BT::leafCount(root);
}

//---------------------------------------------------
//Counts number of leaves in BST
//--------------------------------------------------
int BT::leafCount(node* root){
	int result = 0;
	if (root->left == NULL && root->right == NULL)
		result += 1;
	if (root->left != NULL)
		result += BT::leafCount(root->left);
	if (root->right != NULL)
		result += BT::leafCount(root->right);
	return result;
}

//-----------------------------------------------------
//Call nodeParent
//----------------------------------------------------
void BT::callParent(int x) {

	BT::nodeParent(root, x);

}

//--------------------------------------------------
//Finds parent of a node
//--------------------------------------------------
void BT::nodeParent(node* root, int value) {
	bool top = false;
	if (root == NULL) {
		cout << "Node does not exist" << endl;
		top = true;
	}

	if ((root->left != NULL && root->left->data == value)
		|| (root->right != NULL && root->right->data == value)) {
		cout << "The parent of " << value << " is " << root->data << endl;
		return;
	}
	
	if (root->left == NULL && root->right == NULL) {
		cout << "only one item in BST" << endl;
		top = true;
	}

	if (root->data > value) {
		BT::nodeParent(root->left, value);
		top = true;
	}

	if (root->data < value) {
		BT::nodeParent(root->right, value);
		top = true;
	}
	if (top == false)
		cout << " Node is topmost item: Has no parent nodes" << endl;
	
}