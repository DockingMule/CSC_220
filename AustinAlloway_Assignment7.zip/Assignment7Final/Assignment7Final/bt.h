#include <iostream>
#ifndef BT_H
#define BT_H
using namespace std;
class BT
{
private:
	struct node
	{
		int data;
		node* left;
		node* right;
	};
	node* root;
public:
	BT(); //Constructor
	bool isEmpty() const { return root == NULL; } //Check for empty
	void insert(int); //Insert item in BST
	void print_inorder(); //In-order traversing driver
	void inorderTrav(node*); //In-order traversing
	void callSearch(int);
	void searchBST(node*, int); //Searches BST for a specific node
	void calldelete(int);
	node* deleteNode(node*, int);
	node* findMinimum(node*);
	int count(); //Count driver
	int leafCount(node*); //Counts number of leaves in BST
	void callParent(int);
	void nodeParent(node*, int); //Finds parent of a node
};
#endif